#include<stdio.h>

void main()
{
	int a,b,c;

	a=4;
	b=6;

	c=a*b;

	printf("multiplication:%d",c);
}