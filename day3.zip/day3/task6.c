#include<stdio.h>

void main()
{
	int Velocity,Time,Distance;

    Distance = 50;
    Time = 10;

	Velocity=Distance/Time;

	printf("Velocity: %d", Velocity);

}