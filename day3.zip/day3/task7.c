#include<stdio.h>

void main()
{
	int a,b,c;

	
	a=5+3;
	b=7-2;
	c=a*b;
    

	printf("c: %d", c);

}