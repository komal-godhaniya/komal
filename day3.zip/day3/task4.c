#include<stdio.h>

void main()
{
	int a,Square;

	a=9;

	Square=a*a;

	printf("Square: %d",Square);


}