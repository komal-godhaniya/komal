#include<stdio.h>

void main()
{
	int a,b,c,sum,avr;

	a=10;
	b=20;
	c=30;


	sum=a+b+c;
	avr=sum/3;


	printf("avr :%d",avr);
}