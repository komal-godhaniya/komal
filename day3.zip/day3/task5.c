#include<stdio.h>

void main()
{
	int p,r,t,Interest;

	p= 1000;
	r= 5;
	t= 2;

	Interest=p*r*t/100;


	printf("Interest: %d",Interest );

}